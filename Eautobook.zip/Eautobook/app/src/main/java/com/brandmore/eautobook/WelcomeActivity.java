package com.brandmore.eautobook;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class WelcomeActivity extends AppCompatActivity {
    private Button p;
    private Button d;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);
        p = (Button) findViewById(R.id.passenger);
        d=  (Button) findViewById(R.id.driver);
        p.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                /*TODO Auto-generated method stub*/

                /*
                 * Intent is just like glue which helps to navigate one activity
                 * to another.
                 */Intent intent = new Intent(WelcomeActivity.this,
                        RegisterActivity.class);
                startActivity(intent); // startActivity allow you to move
            }
        });
        d.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                /*TODO Auto-generated method stub*/

                /*
                 * Intent is just like glue which helps to navigate one activity
                 * to another.
                 */Intent intent = new Intent(WelcomeActivity.this,
                        driver.class);
                startActivity(intent); // startActivity allow you to move
            }
        });
    }
}
